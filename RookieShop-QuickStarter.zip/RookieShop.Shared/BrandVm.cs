﻿namespace RookieShop.Shared
{
    public class BrandVm
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
