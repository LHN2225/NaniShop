+ Move hardcode link to configuration
+ Hosting
+ English, TechSkills, SoftSkills

#Reference
https://github.com/thiennn/RookieShop
https://docs.microsoft.com/en-us/aspnet/core/security/authentication/claims?view=aspnetcore-5.0